using Microsoft.AspNetCore.Mvc;
using BSIT_32E1_Elective_2_Assignment_1.Models;

namespace BSIT_32E1_Elective_2_Assignment_1.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        var questions = new List<QuizQuestion>
        {
            new() { Number = 1, Question = "What is the fundamental difference between Server-Side Rendering (SSR/MVC) and a Decoupled Web API architecture?", Answer = "B) SSR compiles HTML views on the server and sends fully rendered markup to the browser, whereas a Web API acts as a stateless data provider returning raw JSON.", Explanation = "MVC renders a user-facing HTML response. A decoupled API normally returns data, commonly JSON, for a separate client to display." },
            new() { Number = 2, Question = "Why do Web API controllers in ASP.NET Core inherit from ControllerBase instead of Controller?", Answer = "B) ControllerBase provides essential HTTP handling and routing without carrying unnecessary HTML view rendering overhead.", Explanation = "ControllerBase includes API-related features such as status-code helpers, while Controller adds view support." },
            new() { Number = 3, Question = "Which framework attribute automatically triggers an HTTP 400 Bad Request response when incoming request payloads fail structural model validation?", Answer = "C) [ApiController]", Explanation = "[ApiController] enables automatic model-state validation responses for invalid API request models." },
            new() { Number = 4, Question = "Which HTTP status code should an API return after successfully creating a new resource via POST, along with a Location header pointing to the new URI?", Answer = "B) 201 Created", Explanation = "201 Created indicates that the request created a resource. The Location header can identify its URI." },
            new() { Number = 5, Question = "When a DELETE request successfully removes a resource and returns no content in the response body, which HTTP status code is standard?", Answer = "C) 204 No Content", Explanation = "204 indicates success with no response body." },
            new() { Number = 6, Question = "Which endpoint URI follows RESTful resource-oriented naming best practices?", Answer = "B) GET /api/courses", Explanation = "The URI names the resource with a plural noun; the HTTP verb communicates the operation." },
            new() { Number = 7, Question = "What is the primary function of [Route(\"api/[controller]\")] in ASP.NET Core?", Answer = "B) It maps incoming URI request paths to the controller class using the class name token.", Explanation = "[controller] is a route token replaced with the controller name (normally without the Controller suffix)." },
            new() { Number = 8, Question = "Which HTTP verb is safe and idempotent, intended exclusively for retrieving resource data without altering server state?", Answer = "C) GET", Explanation = "GET is intended to retrieve a representation and should not change server state; it is safe and idempotent." },
            new() { Number = 9, Question = "In ASP.NET Core Web API, what wrapper type allows action methods to return either a strongly typed domain object or standard HTTP status result helpers (such as Ok(), NotFound() )?", Answer = "Likely: ActionResult<T> (the question's answer choices were cut off).", Explanation = "ActionResult<T> supports returning either a value of type T or an IActionResult-style HTTP result. Please verify against the complete answer choices." }
        };

        return View(questions);
    }
}
