namespace BSIT_32E1_Elective_2_Assignment_1.Models;

public class QuizQuestion
{
    public int Number { get; set; }
    public string Question { get; set; } = "";
    public string Answer { get; set; } = "";
    public string Explanation { get; set; } = "";
}
