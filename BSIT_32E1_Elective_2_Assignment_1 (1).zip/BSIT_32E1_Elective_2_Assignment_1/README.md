# BSIT_32E1_Elective_2_Assignment_1

An ASP.NET Core MVC (.NET 8) application that displays the supplied assignment questions, selected answers, and short explanations.

## Run the application
1. Install the .NET 8 SDK.
2. Open a terminal in this project folder.
3. Run `dotnet restore`.
4. Run `dotnet run`.
5. Open the localhost URL shown in the terminal.

## Important
Question 9 was cut off after option A) `Task...` in the supplied prompt. The app uses `ActionResult<T>` as the likely answer based on the question wording. Confirm it against the complete options before submitting.
